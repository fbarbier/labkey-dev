SELECT 
"Lab Results".ParticipantId,
"Lab Results".date,
'CD4' AS Test,
"Lab Results".CD4 AS Result
FROM "Lab Results"

UNION ALL

SELECT 
"Lab Results".ParticipantId,
"Lab Results".date,
'Lymphocytes' AS Test,
"Lab Results".Lymphocytes AS Result
FROM "Lab Results"

UNION ALL

SELECT 
"Lab Results".ParticipantId,
"Lab Results".date,
'Hemoglobin' AS Test,
"Lab Results".Hemoglobin AS Result
FROM "Lab Results"

UNION ALL

SELECT 
"Lab Results".ParticipantId,
"Lab Results".date,
'ViralLoad' AS Test,
"Lab Results".ViralLoad AS Result
FROM "Lab Results"
