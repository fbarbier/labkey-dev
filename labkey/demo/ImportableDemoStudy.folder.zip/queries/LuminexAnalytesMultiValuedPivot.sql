SELECT ParticipantId, date, Analyte, 
  Count(Analyte) AS NumberOfValues,
  AVG(FI) AS AverageFI, 
  MAX(FI) AS MaxFI
FROM "Luminex Assay 100"
GROUP BY ParticipantID, date, Analyte
PIVOT AverageFI, MaxFI BY Analyte
